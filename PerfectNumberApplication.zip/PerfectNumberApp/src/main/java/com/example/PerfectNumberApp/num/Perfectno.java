package com.example.PerfectNumberApp.num;





import java.util.Arrays;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import netscape.javascript.JSObject;

@RestController
public class Perfectno {

	
	@GetMapping(value="/test{a}{b}")
	
	public static int[] isPerfectNumber(@RequestParam("a") int starting_number, @RequestParam("b") int ending_number) {
		int array[] = new int[5];
		int sum = 0;
		int i;
		int k=0;
		 

		for (i = starting_number; i <= ending_number; i++) {
			sum=0;
			for (int j = 1; j <i; j++) {
				if (i % j == 0)
				{
					sum = sum + j;
				}
				
			}
			if (sum == i)
			{
				
				array[k] = sum;
				 
				 k++;
			}

		}

		return array;

	}

}