package com.example.PerfectNumber.num;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfectNumberAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
