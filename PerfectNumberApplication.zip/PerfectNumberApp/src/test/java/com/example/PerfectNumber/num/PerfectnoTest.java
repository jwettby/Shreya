package com.example.PerfectNumber.num;

import java.sql.Array;
import java.util.Arrays;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.PerfectNumberApp.num.Perfectno;

@SpringBootTest(classes= {PerfectnoTest.class})
public class PerfectnoTest {

	
	@InjectMocks
	Perfectno perfectno;

	@Test
	public void test_isPerfectNumber()
	{
		 int[] expected ={6,28,496,8128,0};
		Assertions.assertEquals(Arrays.toString(expected),Arrays.toString(perfectno.isPerfectNumber(1, 10000))); 
		
	}
	
}
